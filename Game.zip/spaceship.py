import pygame
class Spaceship:
    def __init__(self):
        super().init()
        
